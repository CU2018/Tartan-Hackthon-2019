#! /bin/sh

cp ../templates_git/ProClass/proclass/templates/*.html ./proclass/templates/
cp ../templates_git/ProClass/proclass/templates/*.css ./proclass/templates/
cp ../templates_git/ProClass/proclass/templates/assets/* ./proclass/static



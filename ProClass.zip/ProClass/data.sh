#! /bin/sh

rm proclass/site.db
python3 init_db.py

from proclass import app
from flask import render_template, request, url_for, session, redirect
from proclass.models import User, Course, Professor, Post

@app.route('/')
def home(): # the root of the website
    if 'email' in session:
        return redirect(url_for('homepage'))
    return redirect(url_for('login'))

@app.route('/homepage', methods=['GET', 'POST'])
def homepage():
    email = session['email']
    user = User.query.filter_by(email=email).first()
    return render_template('homepage.html', user=user)
    # if 'email' in session:
    #     user = User.query.filter_by(email=session['email'])
    #     return render_template('homepage.html', user=user)
    # else:
    #     return redirect()
def get_professors_by_class(class_name):
    courses = Course.query.filter_by(course_name=class_name)
    professors = [Professor.query.filter_by(id=course.professor_id).first() for course in courses]
    return professors
    # return [professor.name for professor in professors]

def get_class_by_professor(professor_name):
    professor = Professor.query.filter_by(name=professor_name).first()
    print([course.course_name for course in professor.courses])
    return professor.courses
    # return [course.course_name for course in professor.courses]

def get_course_rating(course):
    return (course.difficulty + course.lecture + course.organization) / 3
def get_rating(professor):
    # get the overall rating of the given professor
    courses = professor.courses
    return None

def sort_by_rating(professors):
    # sort the professors by the overall rating
    rating_ordered = sorted(professors, key=get_rating(professor))
    return None

@app.route('/class_search', methods=['GET', 'POST'])
def class_search():
    class_name = request.form['classinput']
    results = get_professors_by_class(class_name) # get the professor taught by the professor
    return render_template('searchresult.html', category='Class', name=class_name, results=results)

@app.route('/professor_search', methods=['GET', 'POST'])
def professor_search():
    professor_name = request.form['professorinput']
    results = get_class_by_professor(professor_name) # get the class taught by the professor
    return render_template('searchresult.html', category='Professor', name=professor_name, results=results)



def num_format(num):
    return '{0:.3g}'.format(num)

@app.route('/pro_class/<class_string>')
def pro_class(class_string):
    infos = class_string.split('_')
    professor = Professor.query.filter_by(name=infos[1]).first()
    #professor_id = professor.id
    course = Course.query.filter_by(course_name=infos[0], professor_id=professor.id).first()
    posts = Post.query.filter_by(course_id=course.id).all()
    difficulty = 0
    organization = 0
    lecture = 0
    for post in posts:
        difficulty += post.difficulty
        organization += post.organization
        lecture += post.lecture
    length = len(posts)
    difficulty = difficulty / length
    organization /= length
    lecture /= length
    overall = (difficulty + organization + lecture) / 3
    # difficulty = num_format(difficulty)
    # organization = num_format(organization)
    # lecture = num_format(lecture)
    # overall = num_format(lecture)
    user = User.query.filter_by(email=session['email']).first()
    return render_template('rate_display.html', user=user, professor=professor, course=course, difficulty=difficulty, organization=organization, lecture=lecture, overall=overall)



@app.route('/user_search', methods=['GET', 'POST'])
def user_search():
    user_name = request.form['userinput']
    user = User.query.filter_by(username=username).first()
    if user:
        return "show the user's public portfolio"
    else:
        return "can't find user"

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form["email"]
        password = request.form["password"]
        user = User.query.filter_by(email=email).first()
        print(user)
        if user and user.password == password:
            # login succeed
            session['email'] = email
            return redirect(url_for('homepage'))
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('email', None)
    return redirect(url_for('login'))

@app.route('/my_portfolio')
def portfolio():
    if 'email' in session:
        print('in session')
    else:
        print('not in session')
    user = User.query.filter_by(email=session['email']).first()
    return render_template('my_portfolio.html', user=user)

@app.route('/chat_room') # fake chat room
def chat_room():
    return render_template('chat_room.html')

@app.route('/class_forum') #
def class_forum():
    return render_template('classforum.html')

@app.route('/rate_display') #
def rate_display():
    return render_template('rate_display.html')

@app.route('/rate')
def rate():
    return render_template('rate.html')

@app.route('/edit_portfolio')
def edit_portfolio():
    return render_template('edit_portfolio_information.html')

@app.route('/professor_information')
def professor_information():
    return render_template('professor_information.html')
